#!/bin/sh

echo > out.sql
#cat school.sql >> out.sql
#python courses.py >> out.sql
#python webinars.py >> out.sql
#python studies.py >> out.sql
#cat triggers/* >> out.sql
#cat indexes/* >> out.sql
#cat ./views/widoki.sql >> out.sql
# cat ./procedures_functions/parameters.sql \
#     ./procedures_functions/studies.sql \
#     ./procedures_functions/courses.sql \
#     ./procedures_functions/webinars.sql \
#     ./procedures_functions/usersAndEmployees.sql \
#     ./procedures_functions/enrollmentAndPayments.sql \
#     ./procedures_functions/viewlike.sql >> out.sql
cat roles/* >> out.sql